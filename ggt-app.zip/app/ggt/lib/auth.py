import ujson
import os
import urllib.request as urllib2
import ssl
from fastapi.security.api_key import APIKeyHeader, APIKey
from fastapi import Depends, Request, HTTPException, Security, Depends
from fastapi.security import SecurityScopes
from google.auth.transport import requests
from google.oauth2 import id_token
from jose import jwt, JWTError
from starlette.status import HTTP_403_FORBIDDEN

import ggt.lib.constants as c

from ggt.lib.oath2_wrapper import GgtOAuth2PasswordBearer

from ggt.lib.utils import (
    log_generic,
    whoami,
    get_config_val
)

from ggt.models.data_models.data_types import (
    User,
    AuthError,
    PermissionsEnum as p)

# TODO: [GGT-81] read from config/DB
CLIENT_ID = "269165607649-ejpvn7ar1llub2e8tr6ur4ad2p1srucf.apps.googleusercontent.com"
# TODO: [GGT-82] read from config/DB as a single value of "tokenUrl" e.g. GgtOAuth2PasswordBearer(tokenUrl=get_config_val('vendors.auth0.auth0_domain'))
oauth2_scheme = GgtOAuth2PasswordBearer(
    tokenUrl="https://" + get_config_val('vendors.auth0.auth0_domain') + "/oauth/token")
api_key_header = APIKeyHeader(
    name='x-api-key',
    auto_error=False
)


# TODO: [GGT-84] read from config/DB
def verify_google_idtoken(token):
    try:
        decoded_token = id_token.verify_oauth2_token(
            token, requests.Request(), CLIENT_ID)

        if (decoded_token['email'].split('@')[1] == "wellpay.com" or
                decoded_token['email'].split('@')[1] == "wellhealth.studio" or
                decoded_token['email'].split('@')[1] == "hrmdmanagement.com" or
                decoded_token['email'].split('@')[1] == "flowermoundpain.co"):
            return True
        else:
            return False

    except Exception as err:
        log_generic(
            type=c.ERROR,
            token=token,
            function=whoami(),
            error=err
        )
        return False


def get_value(user, key):
    if key in user.keys():
        return str(user[key])
    else:
        return ""


def get_rsa_key(token):
    if 'RSA_KEY' in os.environ:
        return ujson.loads(os.environ.get('RSA_KEY'))

    else:
        rsa_key = get_rsa_key_auth0(token)
        return rsa_key


# TODO: [GGT-83] read from config/DB as already concatinated value of tokenUrl or use a function that generates these auth0 urls


def get_rsa_key_auth0(token):
    jsonurl = urllib2.urlopen(
        "https://" +
        get_config_val('vendors.auth0.auth0_domain') +
        "/.well-known/jwks.json",
        context=ssl._create_unverified_context())
    jwks = ujson.loads(jsonurl.read())

    try:
        unverified_header = jwt.get_unverified_header(token)
        rsa_key = {}
        for key in jwks["keys"]:
            if key["kid"] == unverified_header["kid"]:
                rsa_key = {
                    "kty": key["kty"],
                    "kid": key["kid"],
                    "use": key["use"],
                    "n": key["n"],
                    "e": key["e"]
                }
                _rsa_key = ujson.dumps(rsa_key)
                os.environ['RSA_KEY'] = _rsa_key

        return rsa_key

    except JWTError as err:
        x = {
            "token": token,
            "jsonurl": "https://" + get_config_val('vendors.auth0.auth0_domain') + "/.well-known/jwks.json"
        }
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )
        raise HTTPException(
            status_code=401, detail="Unable to find appropriate key {}".format(ujson.dumps(x)))


def authorize_user(security_scopes: SecurityScopes, token: str = Depends(oauth2_scheme)):
    """
    NOTE - Uncommenting this will affect the Organization flow
    """
    # if get_config_val('env') == 'LOCAL-PROD':  # Allow auth override for local-prod
    #     return True
    try:
        scopes = security_scopes.scopes
        if p.ANONYMOUS in scopes:
            return True
        elif token is not None:
            auth = authorize(scopes, token)
            return auth
        else:
            raise HTTPException(status_code=401, detail=c.AUTH_FAILED_MESSAGE)

    except AuthError as err:
        print(err)
        return None


def authorize(scopes, token):
    """Determines if the Access Token is valid
    """
    rsa_key = get_rsa_key(token)
    if rsa_key:
        try:
            user = jwt.decode(
                token,
                rsa_key,
                algorithms=get_config_val('vendors.auth0.algorithms'),
                audience=get_config_val('vendors.auth0.api_audience'),
                issuer="https://" +
                       get_config_val('vendors.auth0.auth0_domain') + "/"
            )

            if len(list(set(user['permissions']).intersection(scopes))) > 0:
                return user
            else:
                raise HTTPException(
                    status_code=401, detail=c.AUTH_FAILED_MESSAGE)
        except jwt.ExpiredSignatureError:
            get_rsa_key_auth0(token)
            raise HTTPException(status_code=401, detail=c.AUTH_FAILED_MESSAGE)
        except jwt.JWTClaimsError:
            get_rsa_key_auth0(token)
            raise HTTPException(status_code=401, detail=c.AUTH_FAILED_MESSAGE)
        except Exception:
            get_rsa_key_auth0(token)
            raise HTTPException(status_code=401, detail=c.AUTH_FAILED_MESSAGE)
    get_rsa_key_auth0(token)
    raise HTTPException(status_code=401, detail=c.AUTH_FAILED_MESSAGE)


async def get_vendor_api_key(api_key_header: str = Security(api_key_header), vcode: str = ''):
    try:
        if api_key_header == get_config_val('vendors.{}.ggt_api.api_key_value'.format(vcode)):
            return api_key_header

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )

    raise HTTPException(
        status_code=HTTP_403_FORBIDDEN,
        detail=c.AUTH_FAILED_MESSAGE
    )
