import os

import boto3
from botocore.config import Config
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Security
)
from ggt.lib.auth import authorize_user
from ggt.lib.constants import (
    STATUS,
    SUCCESS,
    AUTH_FAILED_MESSAGE
)
from ggt.lib.email import send_email, render_template
from ggt.lib.sms import send_sms
from ggt.lib.utils import (
    get_config_val,
    is_contact_center, is_international
)
from ggt.models.data_models.data_types import (
    CCSendSMSRequest,
    CCSendEmailRequest,
    CCSendNotiRequest,
    CCOutboundResultRequest,
    CCOutboundResultStatusRequest,
    User,
    PermissionsEnum as p
)
from ggt.models.workflow_models.contact_center_flow import (
    cc_update_outbound_call_status
)

my_config = Config(
    region_name='us-east-1',
)
os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAR7AATMMMF2D7H352'
os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
client = boto3.client('connect', config=my_config)

router = APIRouter()


def formatted_sms_message(first_name, token):
    base_url = get_config_val('base_url')
    return "Hi {}, your COVID-19 test results are ready. " \
           "Follow this link to view {}/r/{} reply STOP to cancel msgs".format(
               first_name, base_url, token)


async def formatted_email_message(first_name, token, to_email):
    base_url = get_config_val('base_url')
    from_email = get_config_val('notifications.from_email')
    from_name = get_config_val('notifications.from_name')
    subject = get_config_val('notifications.result_subject')

    template_vars = {
        "first_name": first_name,
        "result_link": "{}/r/{}".format(base_url, token)
    }

    template_name = get_config_val('notifications.result_template')
    html_content = render_template(template_name, **template_vars)

    email_message = {
        'from_email': from_email,
        'from_name': from_name,
        'to_email': to_email,
        'subject': subject,
        'html_content': html_content
    }

    return email_message


@router.post("/sendsms", dependencies=[Security(authorize_user, scopes=[p.SENDSMS])])
async def api_cc_send_sms(CCSendSMSRequest: CCSendSMSRequest):
    try:
        international = is_international(CCSendSMSRequest.to_number)
        send_sms(
            CCSendSMSRequest.to_number,
            formatted_sms_message(
                CCSendSMSRequest.first_name,
                CCSendSMSRequest.token
            ),
            international=international
        )
        return {STATUS: SUCCESS}

    except Exception as err:
        print(err)


@router.post("/sendemail", dependencies=[Security(authorize_user, scopes=[p.SENDEMAIL])])
async def api_cc_send_email(CCSendEmailRequest: CCSendEmailRequest):
    try:
        email = formatted_email_message(
            CCSendEmailRequest.first_name, CCSendEmailRequest.token, CCSendEmailRequest.to_email)
        send_email(email["from_email"], email["from_name"],
                         email["to_email"], email["subject"], email["html_content"])
        return {STATUS: SUCCESS}

    except Exception as err:
        print(err)


@router.post("/sms_email_notify", dependencies=[Security(authorize_user, scopes=[p.SMS_EMAIL_NOTIFY])])
async def api_cc_send_sms_email(CCSendNotiRequest: CCSendNotiRequest):
    try:
        email = await formatted_email_message(
            CCSendNotiRequest.first_name, CCSendNotiRequest.token, CCSendNotiRequest.to_email)
        send_email(email["from_email"], email["from_name"],
                         email["to_email"], email["subject"], email["html_content"])
        international = is_international(CCSendSMSRequest.to_number)
        send_sms(CCSendNotiRequest.to_number, formatted_sms_message(
            CCSendNotiRequest.first_name, CCSendNotiRequest.token), international=international)
        return {STATUS: SUCCESS}

    except Exception as err:
        print(err)


@router.post("/outbound_result_status", dependencies=[Security(authorize_user, scopes=[p.OUTBOUND_RESULT_STATUS])])
async def outbound_result_status(CCOutboundResultStatusRequest: CCOutboundResultStatusRequest):
    try:
        cc_update_outbound_call_status(
            CCOutboundResultStatusRequest.test_id,
            CCOutboundResultStatusRequest.first_name,
            CCOutboundResultStatusRequest.test_date,
            CCOutboundResultStatusRequest.dob,
            CCOutboundResultStatusRequest.token,
            CCOutboundResultStatusRequest.to_email,
            CCOutboundResultStatusRequest.to_number,
            CCOutboundResultStatusRequest.test_result,
            CCOutboundResultStatusRequest.call_status
        )

    except Exception as err:
        print(err)
