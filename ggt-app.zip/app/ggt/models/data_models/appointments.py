from datetime import datetime
from contextlib import suppress
from uuid import uuid4

import ggt.lib.constants as c

from ggt.lib.utils import (
    log_generic,
    whoami,
    is_non_empty_value
)

from ggt.lib.db import (
    exec_insert,
    exec_update,
    exec_delete,
    read_row,
    read_rows,
    replica_read_row,
    replica_read_rows
)
from ggt.models.data_models.billers import create_insurance_record

from ggt.models.data_models.data_types import (
    GgtAppointment,
    GgtBooking,
    GgtLocation,
    GgtPatient, TestResultEnum, YesNoEnum, InsuranceRecord
)

from ggt.models.data_models.clinical_test_sample import (
    create_test_sample_from_appointment
)


########################################################################################################
# [Public] functions
########################################################################################################


def create_appointment(appointment_req: GgtBooking, ggv_slot=1):
    try:
        sql = """
        INSERT INTO appointments
        (
            scheduled_dt,
            location_id,
            patient_id,
            patient_questionnaire_id,
            group_code,
            total_cost,
            billed_amount,
            wp_receipt_token,
            language
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        vals = (
            appointment_req.timeslot.start_dt,
            appointment_req.location_id,
            appointment_req.patient_id,
            appointment_req.patient_questionnaire_id,
            appointment_req.group_code,
            appointment_req.total_cost / 100,  # cents --> decimal
            appointment_req.billed_amount / 100,  # cents --> decimal
            str(uuid4()),
            appointment_req.language
        )
        appointment_id = exec_insert(sql, vals)
        __add_services_to_appointment(
            appointment_id, appointment_req, ggv_slot=ggv_slot)
        return get_appointment(appointment_id)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            appointment_req=appointment_req,
            error=err
        )

    return None


def add_service_to_appointment(appointment_id: int, service_code: str) -> bool:
    try:
        sql = """
        INSERT INTO appointment_services
        (
            appointment_id,
            service_id,
            service_description,
            price,
            selfpay_amount,
            copay_amount,
            insurance_amount
        )
        SELECT
            %s as appointment_id,
            id as service_id,
            service_name,
            price,
            selfpay_amount,
            copay_amount,
            insurance_amount
        FROM
            services_catalog
        WHERE
            service_code = %s

        """
        vals = (appointment_id, service_code)
        if exec_insert(sql, vals):
            return True

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            appointment_id=appointment_id,
            service_code=service_code,
            error=err
        )

    return False


def get_appointment(appointment_id: int, org_id=None) -> GgtAppointment:

    where_clause = "a.id = %s"
    vals = (appointment_id, )
    if is_non_empty_value(org_id):
        where_clause += ' AND org.id = %s '
        vals = vals + (org_id, )

    try:
        sql = """
        SELECT
            a.*,
            l.addr1 AS location_addr1,
            l.addr2 AS location_addr2,
            l.city AS location_city,
            l.st AS location_st,
            l.zip AS location_zip,
            l.lat,
            l.lng,
            p.dob AS patient_dob,
            p.first_name AS patient_first_name,
            p.middle_name AS patient_middle_name,
            p.last_name AS patient_last_name,
            p.addr1 AS patient_addr1,
            p.addr2 AS patient_addr2,
            p.city AS patient_city,
            p.st AS patient_st,
            p.zip AS patient_zip,
            p.phone_number AS patient_phone_number,
            p.email,
            p.gender,
            p.dob,
            p.token,
            p.result_token,
            GROUP_CONCAT(c.service_code) as service_codes,
            GROUP_CONCAT(s.service_description) as service_descriptions,
            org.name as org_name
        FROM
            appointments a
                JOIN
            patients p ON a.patient_id = p.id
                JOIN
            locations l ON a.location_id = l.id
                LEFT JOIN
            appointment_services s ON (s.appointment_id = a.id)
                LEFT JOIN
            services_catalog c ON (c.id = s.service_id)
				LEFT JOIN
			organizations org ON org.id = l.org_id
        WHERE {}     
        """.format(where_clause)
        row = read_row(sql, vals)

        if not row:
            raise ValueError('No Appointment info')

        return __map_row_to_appointment(row)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment_id,
            function=whoami(),
            error=err
        )

    return None


# Invalid query, not used anywhere
def get_ggv_patient(patient_id: int):
    try:
        where_statement = "ggv.patient_id = {}".format(patient_id)
        sql = """
        SELECT
            l.addr1 AS location_addr1,
            l.addr2 AS location_addr2,
            l.city AS location_city,
            l.st AS location_st,
            l.zip AS location_zip,
            l.lat,
            l.lng,
            p.id,
            p.dob AS patient_dob,
            p.first_name AS patient_first_name,
            p.middle_name AS patient_middle_name,
            p.last_name AS patient_last_name,
            p.addr1 AS patient_addr1,
            p.addr2 AS patient_addr2,
            p.city AS patient_city,
            p.st AS patient_st,
            p.zip AS patient_zip,
            p.phone_number AS patient_phone_number,
            p.email,
            p.gender,
            p.dob,
            p.token,
            p.result_token,
            GROUP_CONCAT(c.service_code) as service_codes,
            GROUP_CONCAT(s.service_description) as service_descriptions,
            org.name as org_name,
            ggv.*
        FROM
            ggv_certificates ggv ON a.patient_id = ggv.patient_id
                JOIN
            patients p ON a.patient_id = p.id
                JOIN
            locations l ON a.location_id = l.id
                LEFT JOIN
            appointment_services s ON (s.appointment_id = a.id)
                LEFT JOIN
            services_catalog c ON (c.id = s.service_id)
				LEFT JOIN
			organizations org ON org.id = l.org_id
        WHERE
                {}
        """.format(where_statement)

        row = read_row(sql)
        return row

    except Exception as err:
        log_generic(
            type=c.ERROR,
            patient_id=patient_id,
            function=whoami(),
            error=err
        )

    return None


def get_monthy_calendar(from_date: str, to_date: str, location_id: int):
    try:
        sql = """
            SELECT *
            FROM
                appointment_with_patient
            WHERE
                scheduled_dt between %s AND %s
                AND location_id = %s
            """

        vals = (from_date, to_date, location_id)
        return read_rows(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            location_id=location_id,
            from_date=from_date,
            to_date=to_date,
            function=whoami(),
            error=err
        )

    return None


def is_open_patient(patient_id):
    try:
        sql = """
            SELECT *
            FROM
                patients
            WHERE
                id = %s AND token_expire > NOW()
            """

        vals = (patient_id,)
        return read_rows(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            patient_id=patient_id,
            function=whoami(),
            error=err
        )

    return None


def positive_result_followup():
    try:
        sql = """
            SELECT
                pos.patient_id,
                pos.test_id,
                pos.dob,
                pos.first_name,
                pos.last_name,
                pos.phone_number,
                pos.email,
                pat.gender,
                pat.addr1,
                patq.heart_disease,
                patq.diabetes,
                patq.respiratory_diseases,
                patq.autoimmune_disease,
                patq.other_chronic,
                patq.allergies,
                patq.prescription_use,
                patq.symptom_fever,
                patq.symptom_shortness_breath,
                patq.symptom_cough,
                patq.symptom_chest_pain,
                patq.symptom_lack_of_smell,
                patq.symptom_lack_of_smell,
                patq.symptom_other_breathing,
                patq.covid_contact
            FROM
                positive_result_followup_queue pos
            INNER JOIN patients pat
                ON pos.patient_id = pat.id
            INNER JOIN patient_questionnaires patq
                ON patq.patient_id = pat.id
            WHERE
                overall_status = %s LIMIT 1
        """

        vals = ("scheduled",)
        return replica_read_row(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )

    return None


def update_appointment_with_receipt_token(appointment: GgtAppointment):
    try:
        sql = """
            UPDATE appointments
            SET
                wp_receipt_token = %s
            WHERE
                id = %s
        """
        vals = (appointment.wp_receipt_token, appointment.id)
        return exec_update(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment=appointment,
            function=whoami(),
            error=err
        )

    return None


def update_positive_result_followup(id: int, date_time: datetime):
    try:
        sql = """
            UPDATE positive_result_followup_queue
            SET
                overall_status = %s, update_dt = %s
            WHERE
                test_id = %s
            """

        vals = ("pending", date_time, id)
        return exec_update(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            id=id,
            date_time=date_time,
            function=whoami(),
            error=err
        )

    return None


def release_ggv_slot(appointment_id):
    try:
        sql = """UPDATE ggv_schedules 
                    SET 
                        status = %s,
                        appointment_id = %s
                    WHERE
                        appointment_id = %s;"""

        vals = ("available", None, appointment_id)
        return exec_update(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment_id,
            function=whoami(),
            error=err
        )
    return None


def lock_ggv_slot(appointment_id, slot_id):
    try:
        sql = """UPDATE ggv_schedules 
                    SET 
                        status = %s,
                        appointment_id = %s
                    WHERE
                        id = %s;"""

        vals = ("booked", appointment_id, slot_id)
        return exec_update(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment_id,
            function=whoami(),
            error=err
        )
    return None


def re_schedule_appointment(appointment_id, slot):
    try:
        sql = """UPDATE appointments
                    SET
                        scheduled_dt = %s,
                        location_id = %s
                    WHERE
                        id = %s"""

        vals = (slot.start_dt, slot.location_id, appointment_id)
        exec_update(sql, vals)
        return get_appointment(appointment_id)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment_id,
            function=whoami(),
            error=err
        )
    return None


def lookup_certificate(phone_number, dob, first_name, last_name, token=None):
    try:
        where_statement = "1=1"
        vals = ()
        if phone_number or phone_number != "":
            where_statement += " AND p.phone_number = %s"
            vals = vals + (phone_number,)
        if dob or dob != "":
            where_statement += " AND date(p.dob) = %s"
            vals = vals + (dob,)
        if first_name or first_name != "":
            where_statement += " AND p.first_name = %s"
            vals = vals + (first_name,)
        if last_name or last_name != "":
            where_statement += " AND p.last_name = %s"
            vals = vals + (last_name,)
        if token:
            where_statement += " AND p.result_token = %s AND p.token_expire > NOW()"
            vals = vals + (token,)
        sql = """SELECT 
                    gc.*,
                   date(gc.check_in_dt) AS appointment_date
                FROM
                    patients p
                        JOIN
                    ggv_certificates gc ON p.id = gc.patient_id
                    WHERE {} AND gc.active=1 AND gc.rejected = 0 """.format(where_statement)
        rows = replica_read_rows(sql, vals)
        return __format_vax_certificate(rows), "No certificate found."

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )
    return None, None


def lookup_pkpass(phone_number, dob, first_name, last_name, token):
    try:

        sql = """SELECT 
                    gc.*,
                    p.*
                FROM
                    patients p
                        JOIN
                    ggv_certificates gc ON p.id = gc.patient_id
                WHERE
                    p.phone_number = %s 
                        AND
                    date(p.dob) = %s
                        AND
                    p.first_name = %s
                        AND
                    p.last_name = %s
                        AND
                    p.result_token = %s 
                        AND
                    p.token_expire > NOW()
                        AND 
                    gc.active=1 
                        AND 
                    gc.rejected = 0
                    order by check_in_dt asc
                """
        vals = (phone_number, dob, first_name, last_name, token)
        rows = replica_read_rows(sql, vals)
        print(rows)
        return __format_pkpass_records(rows)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )
    return None


def lookup_pkpass_for_portal(phone_number, dob, first_name, last_name):
    try:

        sql = """SELECT 
                    gc.*,
                    p.*
                FROM
                    patients p
                        JOIN
                    ggv_certificates gc ON p.id = gc.patient_id
                WHERE
                    p.phone_number = %s 
                        AND
                    date(p.dob) = %s
                        AND
                    p.first_name = %s
                        AND
                    p.last_name = %s
                        AND 
                    gc.active=1 
                        AND 
                    gc.rejected = 0
                    order by check_in_dt asc
                """
        vals = (phone_number, dob, first_name, last_name)
        rows = replica_read_rows(sql, vals)
        print(rows)
        return __format_pkpass_records(rows)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )
    return None


def save_android_pass_details(id, classId, objectId):
    try:
        sql = """INSERT INTO android_passes (patient_id, class_id, objectId, update_dt)
                    VALUES(%s, %s, %s, NOW()) ON DUPLICATE KEY UPDATE 
                    patient_id = VALUES(patient_id),
                    class_id = VALUES(class_id),
                    objectId = VALUES(objectId),
                    update_dt = VALUES(update_dt)
                    """
        vals = (id, classId, objectId)
        return exec_insert(sql, vals)
    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )
    return None


def get_appointment_count_by_phone_dob(phone_number, dob):
    try:
        if dob:
            sql = """
            SELECT
                COUNT(*) AS count
            FROM
                appointments a
                    JOIN
                patients p ON (p.id = a.patient_id)
            WHERE
                p.phone_number = %s
                AND p.dob = %s
            """
            vals = (phone_number, dob)

        else:
            sql = """
            SELECT
                COUNT(*) AS count
            FROM
                
                patients p
                    LEFT JOIN
                appointments a ON (p.id = a.patient_id)
            WHERE
                p.phone_number = %s
            """
            vals = (phone_number,)

        row = replica_read_row(sql, vals)
        if row:
            return row['count']

    except Exception as err:
        log_generic(
            type=c.ERROR,
            phone_number=phone_number,
            dob=dob,
            function=whoami(),
            error=err
        )

    return 0


def update_appointment_with_confirmed_scheduled(appointment: GgtAppointment, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_SCHEDULED,
                                       operator_location_id=operator_location_id)


def update_appointment_with_checkin(appointment: GgtAppointment, user, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_CHECKED_IN, user=user,
                                       operator_location_id=operator_location_id)


def update_appointment_with_start_vax(appointment: GgtAppointment, user, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_ACTION_START_VAX, user=user,
                                       operator_location_id=operator_location_id)


def update_appointment_with_confirm_insurance_status(appointment: GgtAppointment, user, insurance_status,
                                                     operator_location_id=None):
    status = c.APPOINTMENT_STATUS_INSURANCE_PENDING
    if insurance_status == YesNoEnum.no:
        status = c.APPOINTMENT_STATUS_NO_INSURANCE
    return __update_appointment_status(appointment, status, user=user,
                                       operator_location_id=operator_location_id)


def update_appointment_with_antigen_results(appointment: GgtAppointment, test_result,
                                            operator_location_id=None):
    return __update_appointment_status_antigen_result(appointment, c.APPOINTMENT_STATUS_TEST_FINALIZED, test_result,
                                                      operator_location_id=operator_location_id)


def update_appointment_with_collect_insurance(appointment: GgtAppointment,
                                              operator_location_id=None):

    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_INSURANCE_COLLECTED,
                                       operator_location_id=operator_location_id)


def update_appointment_with_verify_insurance(appointment: GgtAppointment, user, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_ACTION_VERIFY_INSURANCE, user=user,
                                       operator_location_id=operator_location_id)


def update_appointment_with_end_vax(appointment: GgtAppointment, user, workstation_id, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_ACTION_END_VAX, user=user,
                                       workstation_id=workstation_id, operator_location_id=operator_location_id)


def update_appointment_with_notes_vax(appointment: GgtAppointment, user, workstation_id, injection_site,
                                      no_adverse_reactions, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_ACTION_NOTES_VAX, user=user,
                                       workstation_id=workstation_id, injection_site=injection_site,
                                       no_adverse_reactions=no_adverse_reactions,
                                       operator_location_id=operator_location_id)


def update_appointment_with_test_start(user, appointment: GgtAppointment, workstation_id, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_TEST_IN_PROGRESS, user=user,
                                       workstation_id=workstation_id, operator_location_id=operator_location_id)


def update_appointment_with_scan_vial(appointment: GgtAppointment, vial_id: str, user, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_VIAL_SCANNED, vial_id, user=user,
                                       operator_location_id=operator_location_id)


def update_appointment_with_scan_vial_vax(appointment: GgtAppointment, vial_data, user, operator_location_id=None):
    return __update_appointment_status(appointment, c.APPOINTMENT_ACTION_SCAN_VIAL_VAX,
                                       vial_id=vial_data.vial_id,
                                       user=user,
                                       lot_no=vial_data.elements.lot_no,
                                       expiration_date=vial_data.elements.expiration_date,
                                       gtin=vial_data.elements.gtin,
                                       operator_location_id=operator_location_id
                                       )


def update_appointment_with_test_completed(appointment: GgtAppointment, user, operator_location_id=None,
                                           is_antigen=False):
    return __update_appointment_status(appointment, c.APPOINTMENT_STATUS_TEST_COMPLETED, user=user,
                                       operator_location_id=operator_location_id, is_antigen=is_antigen)


def get_service_type_by_appointment_id(appointment_id):
    sql = """SELECT 
                    (CASE
                        WHEN
                            c.service_code LIKE '%VACCINE%'
                        THEN
                             "vax"
                        ELSE "test"
                    END) AS appointment_type
                FROM
                    appointments a
                        JOIN
                    appointment_services s ON a.id = s.appointment_id
                        JOIN
                    services_catalog c ON s.service_id = c.id
                WHERE
                    a.id = %s"""
    vals = (appointment_id,)
    return replica_read_row(sql, vals)


def create_consultation_note(user, appointment_id, appointment_notes):
    provider_external_id = user['sub']
    sql = """INSERT INTO `patient_consultations`
                        (
                        `provider_external_id`,
                        `appointment_id`,
                        `start_dt`,
                        `end_dt`,
                        `consultation_type_code`,
                        `notes`
                        )
                    VALUES
                        (%s, %s, NOW(), NOW(), %s, %s); """
    vals = (provider_external_id, appointment_id,
            'vax_consultation', appointment_notes)
    return exec_insert(sql, vals)


def update_appointment_with_payment_session(appointment: GgtAppointment):
    sql = """UPDATE `appointments`
                        SET
                        payment_session = %s
                    WHERE
                        id = %s; """
    vals = (appointment.payment_checkout_session, appointment.id)
    return exec_update(sql, vals)


def update_appointment_status_to_checked_in(appointment_id):
    sql = """UPDATE `appointments`
                        SET
                        status = %s
                    WHERE
                        status = %s AND id = %s; """
    vals = (c.APPOINTMENT_STATUS_CHECKED_IN,
            c.APPOINTMENT_STATUS_INSURANCE_PENDING, appointment_id)
    return exec_update(sql, vals)


########################################################################################################
# [Protected] functions
########################################################################################################

def __format_vax_certificate(rows):
    try:
        if len(rows) > 0:
            certificates = {
                'patient_id': rows[0]['patient_id'],
                'certificates': []
            }

            for row in rows:
                image = "/api/vax_certificate/{}/{}.jpg".format(
                    row['patient_id'], row['id'])
                service = {
                    "cert_id": row['id'],
                    "appointment_id": row['appointment_id'],
                    "appointment_date": row['appointment_date'],
                    "patient_questionnaire_id": row['patient_questionnaire_id'],
                    "brand": __get_brand(row['service_code']),
                    "service_code": row['service_code'],
                    "lot_no": row['lot_no'],
                    "appointment_time": None,
                    "org_name": None,
                    "verification_level": row['verification_level'],
                    "images": [image]
                }
                certificates['certificates'].append(service)
            return certificates
        else:
            return {}

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )


def __format_pkpass_records(rows):
    try:
        if len(rows) > 0:
            pkpass = {
                'patient_id': rows[0]['patient_id'],
                'first_name': rows[0]['first_name'],
                'last_name': rows[0]['last_name'],
                'dob': rows[0]['dob'].strftime('%m/%d/%Y'),
                'level': str(rows[0]['verification_level']),
                'verfiedDate': rows[0]['create_dt'].strftime('%m/%d/%Y'),
                'certificates': [],
                'certNo': str(rows[0]['id'])
            }
            for row in rows:
                service = {
                    "appointment_id": row['appointment_id'],
                    "appointment_date": row['check_in_dt'].strftime('%m/%d/%Y'),
                    "brand": __get_brand(row['service_code']),
                    "service_code": row['service_code'],
                    "lot_no": str(row['lot_no'])
                }
                pkpass['certificates'].append(service)
            return pkpass
        else:
            return {}

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )


def __get_brand(service_code):
    if service_code == c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_1 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_2 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_3:
        return "Pfizer"
    elif service_code == c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_1 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_2 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_3:
        return "Moderna"
    elif service_code == c.SERVICE_CODE_COVID_19_VACCINE_JNJ:
        return "J & J"
    elif service_code == c.SERVICE_CODE_COVID_19_VACCINE_NOVAVAX_1 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_NOVAVAX_2:
        return "Novavax"
    elif service_code == c.SERVICE_CODE_COVID_19_VACCINE_AZ_1 or service_code == c.SERVICE_CODE_COVID_19_VACCINE_AZ_2:
        return "AstraZeneca"
    else:
        return ""


def __get_mapped_dt_field(status: str) -> str:
    switcher = {
        c.APPOINTMENT_STATUS_SCHEDULED: 'update_dt',
        c.APPOINTMENT_STATUS_CHECKED_IN: 'check_in_dt',
        c.APPOINTMENT_STATUS_INSURANCE_COLLECTED: 'check_in_dt',
        c.APPOINTMENT_STATUS_INSURANCE_PENDING: 'check_in_dt',
        c.APPOINTMENT_STATUS_NO_INSURANCE: 'check_in_dt',
        c.APPOINTMENT_STATUS_TEST_IN_PROGRESS: 'test_start_dt',
        c.APPOINTMENT_STATUS_VIAL_SCANNED: 'test_start_dt',
        c.APPOINTMENT_ACTION_VERIFY_INSURANCE: 'test_start_dt',
        c.APPOINTMENT_ACTION_START_VAX: 'vax_start_dt',
        c.APPOINTMENT_ACTION_SCAN_VIAL_VAX: 'vax_start_dt',
        c.APPOINTMENT_ACTION_END_VAX: 'vax_end_dt',
        c.APPOINTMENT_ACTION_NOTES_VAX: 'vax_notes_dt',
        c.APPOINTMENT_STATUS_TEST_COMPLETED: 'test_end_dt'
    }
    dt_field = switcher.get(status, None)

    if dt_field is None:
        raise ValueError('Invalid Status: {}'.format(status))

    return dt_field


def __update_appointment_status_antigen_result(appointment: GgtAppointment, status, test_result: TestResultEnum,
                                               operator_location_id=None):
    try:
        stat = None
        if test_result.value == "negative":
            stat = 'neg'
        elif test_result.value == "positive":
            stat = 'pos'

        sql = """UPDATE appointments
                    SET
                        update_dt = NOW(),
                        status = %s,
                        sample_collection_location_id = %s
                    WHERE
                        id = %s
                                     """

        vals = (status, operator_location_id, appointment.id)
        success_1 = exec_update(sql, vals)

        sql_2 = """UPDATE test_samples 
                    SET 
                        lab_electronic_submission_dt = NOW(),
                        test_result = %s,
                        status = %s
                    WHERE
                        id = %s;"""
        vals_2 = (stat, 'with_lab', appointment.id)
        success_2 = exec_update(sql_2, vals_2)

        return success_1 and success_2

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment.id,
            status=status,
            function=whoami(),
            error=err
        )
    return False


def __update_appointment_status(appointment: GgtAppointment, status: str, vial_id: str = None, user=None,
                                workstation_id=None, injection_site=None, no_adverse_reactions=None, lot_no=None,
                                expiration_date=None,
                                gtin=None, operator_location_id=None, is_antigen=False):
    vial_id = None if vial_id == '' else vial_id
    usuccess = False
    reason_code = ''

    log_generic(
        position=3,
        type=c.INFO,
        appointment_id=appointment.id,
        function=whoami(),
        action=status,
        workstation_id=workstation_id,
        operator_location_id=operator_location_id,
        vial_id=vial_id,
        injection_site=injection_site
    )

    try:
        # Check if a vial has already been assigned, if so, don't allow update to proceed
        if appointment.vial_id and vial_id:
            print('vial has already been assigned')
            reason_code = 'already_assigned'
            return usuccess, reason_code

        if vial_id:
            # check if vial is a dupe
            sql = """
                SELECT COUNT(*) as count FROM appointments WHERE vial_id = %s
            """
            vals = (vial_id,)
            row = replica_read_row(sql, vals)

            if row['count'] > 0:
                print('duplicate vial ID')
                reason_code = 'dupe'
                return usuccess, reason_code

            # proceed with updating vial_id
            sql = """
                UPDATE appointments
                SET
                    {} = NOW(),
                    update_dt = NOW(),
                    vial_id = %s,
                    status = %s,
                    lot_no = %s,
                    expiration_date = %s,
                    gtin = %s,
                    sample_collection_location_id = %s
                WHERE
                    id = %s
                """.format(__get_mapped_dt_field(status))
            vals = (vial_id, status, lot_no, expiration_date,
                    gtin, operator_location_id, appointment.id)

        else:
            # proceed with updating other info
            if injection_site and no_adverse_reactions:
                sql = """
                                UPDATE appointments
                                SET
                                    {} = NOW(),
                                    update_dt = NOW(),
                                    status = %s,
                                    injection_site = %s,
                                    sample_collection_location_id = %s,
                                    no_adverse_reactions = %s
                                WHERE
                                    id = %s
                                """.format(__get_mapped_dt_field(status))
                vals = (status, injection_site, operator_location_id,
                        no_adverse_reactions, appointment.id)

            else:
                sql = """
                                UPDATE appointments
                                SET
                                    {} = NOW(),
                                    update_dt = NOW(),
                                    status = %s,
                                    sample_collection_location_id = %s
                                WHERE
                                    id = %s
                                """.format(__get_mapped_dt_field(status))

                vals = (status, operator_location_id, appointment.id)

        usuccess = exec_update(sql, vals)
        __create_provider_appointment_activity(user, appointment.id, whoami(), status, vial_id=vial_id,
                                               workstation_id=workstation_id, operator_location_id=operator_location_id)

        # Allow creating a test record only if the test is completed (or in the last step) with a valid vial_id attached
        if usuccess and (
                status == c.APPOINTMENT_STATUS_TEST_COMPLETED or status == c.APPOINTMENT_STATUS_VIAL_SCANNED) and \
                (vial_id or is_antigen):
            create_test_sample_from_appointment(appointment.id)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment.id,
            status=status,
            function=whoami(),
            error=err
        )

    return usuccess, reason_code


def __has_insurance_info(appointment_id):
    sql = """SELECT 
                pq.*
            FROM
                patient_questionnaires pq
                    JOIN
                appointments a ON pq.id = a.patient_questionnaire_id
            WHERE
                a.id = %s;"""
    vals = (appointment_id,)
    row = replica_read_row(sql, vals)
    if row['has_insurance_photo'] == 1:
        return True
    else:
        return False


def __create_provider_appointment_activity(user, appointment_id, function, status, vial_id=None,
                                           workstation_id=None, operator_location_id=None):
    # fail gracefully
    try:
        if user:
            user_ext_id = user['sub']
            sql = """INSERT INTO provider_appointment_activity_history
                        (
                            appointment_id,
                            provider_ext_id,
                            function,
                            status,
                            vial_id,
                            workstation_id,
                            sample_collection_location_id
                        )
                    VALUES
                        (%s, %s, %s, %s, %s, %s, %s)"""

            vals = (appointment_id, user_ext_id, function, status,
                    vial_id, workstation_id, operator_location_id)
            exec_insert(sql, vals)

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            error=err
        )


def __map_row_to_appointment(row: dict) -> GgtAppointment:
    try:
        l = GgtLocation()
        l.id = row['location_id']
        l.addr1 = row['location_addr1']
        l.addr2 = row['location_addr2']
        l.city = row['location_city']
        l.st = row['location_st']
        l.zip = row['location_zip']
        l.lat = row['lat']
        l.lng = row['lng']

        p = GgtPatient()
        p.id = row['patient_id']
        p.dob = row['patient_dob']
        p.first_name = row['patient_first_name']
        p.middle_name = row['patient_middle_name']
        p.last_name = row['patient_last_name']
        p.addr1 = row['patient_addr1']
        p.addr2 = row['patient_addr2']
        p.city = row['patient_city']
        p.st = row['patient_st']
        p.zip = row['patient_zip']
        p.phone_number = row['patient_phone_number']
        p.email = row['email']
        p.gender = row['gender']
        p.dob = row['dob']

        a = GgtAppointment()
        a.id = row['id']
        a.location_id = row['location_id']
        a.org_name = row['org_name']
        a.scheduled_dt = row['scheduled_dt']
        a.group_code = row['group_code']
        a.patient_id = row['patient_id']
        a.patient_questionnaire_id = row['patient_questionnaire_id']
        a.language = row['language']

        a.check_in_dt = row['check_in_dt']
        a.test_start_dt = row['test_start_dt']
        a.test_end_dt = row['test_end_dt']

        a.vial_id = row['vial_id']

        a.wp_customer_info_id = row['wp_customer_info_id']
        a.total_cost = row['total_cost']
        a.billed_amount = row['billed_amount']
        a.wp_receipt_token = row['wp_receipt_token']

        with suppress(AttributeError):
            a.service_selection_codes = row['service_codes'].split(',')
            a.service_selection = row['service_descriptions'].split(',')

        a.location = l
        a.patient = p
        a.status = row['status']

        a.date_text = a.scheduled_dt.strftime(
            "%a, %-d %b %Y @ %-I:%M %p")
        # e.g. 6155 Sports Village Rd, Frisco, TX 75033
        a.location_text = "{}, {} {}  {}".format(
            l.addr1,
            l.city,
            l.st,
            l.zip
        )

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=row,
            function=whoami(),
            error=err
        )

    return a


def __add_services_to_appointment(appointment_id: int, appointment_req: GgtBooking, ggv_slot=1) -> bool:
    try:
        # if appointment_req.service_covid19_vaccine:
        #     vaccine_service_code = __get_vaccine_service_code_for_location(
        #         appointment_req.location_id,
        #         ggv_slot=ggv_slot
        #     )
        #     add_service_to_appointment(appointment_id, vaccine_service_code)

        if appointment_req.services.covid_19_vax_jnj:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_JNJ)

        if appointment_req.services.covid_19_vax_moderna_1 and ggv_slot == 1:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_1)

        if appointment_req.services.covid_19_vax_moderna_2 and ggv_slot == 2:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_2)

        if appointment_req.services.covid_19_vax_pfizer_1 and ggv_slot == 1:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_1)

        if appointment_req.services.covid_19_vax_pfizer_2 and ggv_slot == 2:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_2)

        if appointment_req.services.covid_19_vax_novavax_1 and ggv_slot == 1:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_NOVAVAX_1)

        if appointment_req.services.covid_19_vax_novavax_2 and ggv_slot == 2:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_NOVAVAX_2)
        if appointment_req.services.covid_19_vax_az_1 and ggv_slot == 1:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_AZ_1)

        if appointment_req.services.covid_19_vax_az_2 and ggv_slot == 2:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_VACCINE_AZ_2)

        if appointment_req.services.covid_19_test:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST)

        if appointment_req.services.covid_19_test_nv:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST_NV)

        if appointment_req.services.covid_19_test_mexico:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST_MEXICO)

        if appointment_req.services.covid_19_test_mexico_resort:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID_19_TEST_MX_RESORT)

        if appointment_req.services.covid_19_test_antigen:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST_ANTIGEN)

        if appointment_req.services.covid_19_test_antigen_mexico:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST_MEXICO_ANTIGEN)

        if appointment_req.services.covid_19_test_antigen_nv:
            add_service_to_appointment(
                appointment_id, c.SERVICE_CODE_COVID19_TEST_ANTIGEN_NV)

        if appointment_req.services.flue_shot:
            add_service_to_appointment(appointment_id, c.SERVICE_CODE_FLU_SHOT)

        if appointment_req.services.consult:
            add_service_to_appointment(appointment_id, c.SERVICE_CODE_CONSULT)

        return True

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            appointment_req=appointment_req,
            error=err
        )
    return False


def __get_vaccine_service_code_for_location(location_id, ggv_slot):
    try:
        sql = """
            SELECT
                sc.service_code as service_code
            FROM
                ggt_prod.services_to_locations_mapping sl
                    LEFT JOIN
                ggt_prod.services_catalog sc ON (sl.service_id = sc.id)
            WHERE
                location_id = %s
                    AND sc.service_code like '%VACCINE%{}'
        """.format(ggv_slot)

        vals = (location_id,)
        row = replica_read_row(sql, vals)

        if not row:
            raise ValueError('No Service Info')

        return row['service_code']

    except Exception as err:
        log_generic(
            type=c.ERROR,
            appointment_id=appointment_id,
            function=whoami(),
            error=err
        )

    return None
