from datetime import date, datetime
from contextlib import suppress

from cachetools import cached, LRUCache, TTLCache

from ggt.lib.utils import (
    log_generic,
    x_response,
    whoami, y_response
)
from ggt.models.data_models.patients import is_un_available_slot, lock_slot

from ggt.models.process_models.bp_patient_experience import (
    bp_get_screen_flow_seq,
    bp_initiate_verification_flow,
    bp_validate_phone_number,
    bp_finalize_booking,
    bp_finalize_payment,
    bp_get_test_result, bp_add_to_ggd_waiting_queue,
    bp_get_wellpay_insurance_eligibility,
    bp_search_insurance_payer_list, bp_get_ggv_screen_flow_seq, bp_ggv_finalize_booking, bp_ggv_finalize_pre_booking,
    bp_create_pre_registration, bp_verify_verification_token, bp_reschedule_first_appointment,
    bp_reschedule_second_appointment, bp_lookup_certificate, bp_get_vax_certificate,
    bp_get_wallet_pass, bp_call_non_sms_phone, bp_add_vax_certificate, bp_update_group_code, bp_add_vax_certificates,
    bp_pass_verification, bp_update_android_pass, bp_vax_wallet_pass_apple_upadte,bp_vax_wallet_pass_apple_upadte_serial, bp_vax_wallet_get_new_pass,
    bp_initiate_vax_verification_flow,
    bp_vax_check_payment, bp_vax_yes_payment, bp_vax_yes_verify_payment
)

from ggt.models.process_models.bp_schedules import (
    bp_get_schedule_dates_available,
    bp_get_schedule_locations_available,
    bp_get_schedule_times_available,
    bp_get_all_available_locations_and_times,
    bp_get_schedule_locations_available_near_lat_lng, bp_ggv_get_schedule_locations_available_near_lat_lng,
    bp_get_second_shot_available_times, bp_get_ggv_schedule_times_available, bp_get_second_slot_reschedule_dates,
    bp_get_ggv_schedule_dates_available
)

from ggt.models.process_models.bp_appointments import (
    bp_get_appointment_info
)

from ggt.models.data_models.data_types import (
    GgtBooking,
    LocationService, ServiceCodes
)

import ggt.lib.constants as c


########################################################################################################
# [Public] functions
########################################################################################################

@cached(cache=TTLCache(maxsize=1024, ttl=600))
def get_screen_flow_seq(group_code, country_code="US"):
    return x_response(
        bp_get_screen_flow_seq(group_code, country_code=country_code)
    )


@cached(cache=TTLCache(maxsize=1024, ttl=600))
def get_ggv_screen_flow_seq(group_code):
    return x_response(
        bp_get_ggv_screen_flow_seq(group_code)
    )


def initiate_verification_flow(phone_number, with_otp=True):
    return x_response(
        bp_initiate_verification_flow(
            phone_number,
            with_otp
        )
    )


def initiate_vax_verification_flow(req):
    return x_response(
        bp_initiate_vax_verification_flow(req)
    )


def reschedule_first_appointment(req):
    return x_response(
        bp_reschedule_first_appointment(
            req.otp,
            req.appointment_id_1,
            req.appointment_id_2,
            req.appointment_1_dt_id,
            req.appointment_2_dt_id,
            req.phone_number
        )
    )


def reschedule_second_appointment(req):
    return x_response(
        bp_reschedule_second_appointment(
            req.appointment_id_1,
            req.appointment_id_2,
            req.appointment_2_dt_id
        )
    )


@cached(cache=TTLCache(maxsize=1024, ttl=60))
def validate_phone_number(phone_number, otp):
    return x_response(
        bp_validate_phone_number(
            phone_number,
            otp
        )
    )


@cached(cache=TTLCache(maxsize=1024, ttl=300))
def get_schedule_dates_available(group_code=c.DEFAULT_GROUP_CODE):
    return x_response(
        bp_get_schedule_dates_available(
            group_code
        )
    )


# @cached(cache=TTLCache(maxsize=1024, ttl=300))
def get_ggv_schedule_dates_available(group_code=c.DEFAULT_GROUP_CODE):
    return x_response(
        bp_get_ggv_schedule_dates_available(
            group_code
        )
    )


@cached(cache=TTLCache(maxsize=1024, ttl=300))
def get_schedule_locations_available(group_code, date):
    return x_response(
        bp_get_schedule_locations_available(
            group_code,
            date
        )
    )


@cached(cache=TTLCache(maxsize=1024, ttl=180))
def get_schedule_locations_available_near_lat_lng(date, group_code, lat, lng, radius):
    return x_response(
        bp_get_schedule_locations_available_near_lat_lng(
            lat,
            lng,
            radius,
            date,
            group_code
        )
    )


# @cached(cache=TTLCache(maxsize=1024, ttl=180))
def get_ggv_schedule_locations_available(group_code, lat, lng, radius):
    return y_response(
        bp_ggv_get_schedule_locations_available_near_lat_lng(group_code, lat, lng, radius)
    )


@cached(cache=TTLCache(maxsize=1024, ttl=120))
def get_all_available_locations_and_times(group_code):
    return x_response(
        bp_get_all_available_locations_and_times(group_code)
    )


@cached(cache=TTLCache(maxsize=1024, ttl=60))
def get_schedule_times_available(
    location_id,
    date=date.today().strftime("%Y-%m-%d")
):
    return x_response(
        bp_get_schedule_times_available(
            location_id,
            date
        )
    )


def get_ggv_schedule_times_available(
    location_id,
    date=date.today().strftime("%Y-%m-%d")
):
    return x_response(
        bp_get_ggv_schedule_times_available(
            location_id,
            date
        )
    )


def get_second_slot_reschedule_dates(location_id, ap1_date):
    return x_response(
        bp_get_second_slot_reschedule_dates(
            location_id,
            ap1_date
        )
    )


def get_second_shot_available_times(req):
    location_id = req.location_id
    if len(req.dates) > 1:
        date = str(tuple((req.dates)))
    elif len(req.dates) == 1:
        date = "('{}')".format(req.dates[0])
    return x_response(
        bp_get_second_shot_available_times(location_id, date)
    )


@cached(cache=TTLCache(maxsize=1024, ttl=60))
def lookup_appointment(appointment_id, dob):
    return x_response(
        bp_get_appointment_info(
            appointment_id,
            dob
        )
    )


@cached(cache=TTLCache(maxsize=1024, ttl=60))
def lookup_certificate(phone_number, dob, first_name, last_name, token):
    log_generic(
        type=c.INFO,
        phone_number=phone_number,
        dob=dob,
        first_name=first_name,
        last_name=last_name,
        token=token,
        msg="CERTIFICATE_LOOKUP-{}".format(phone_number),
        function=whoami()
    )
    res = bp_lookup_certificate(
            phone_number,
            dob,
            first_name,
            last_name,
            token
        )

    if res[0] is None:
        log_generic(
            type=c.INFO,
            phone_number=phone_number,
            dob=dob,
            first_name=first_name,
            last_name=last_name,
            token=token,
            msg="CERTIFICATE_LOOKUP_FAILED - {}".format(phone_number),
            function=whoami()
        )

    return y_response(res[0], reason_code=res[1])


@cached(cache=TTLCache(maxsize=1024, ttl=60))
def lookup_test_result(token, dob):
    return x_response(
        bp_get_test_result(
            token,
            dob
        )
    )


def finalize_payment(finalize_payment_request):
    appointment_id = finalize_payment_request.appointment_id
    wp_receipt_token = finalize_payment_request.receipt_token

    if bp_finalize_payment(appointment_id, wp_receipt_token):
        return {c.STATUS: c.SUCCESS}
    else:
        return {c.STATUS: c.FAILED}


def finalize_registration(finalize_registration_request):
    booking_req = __map_to_booking_req(finalize_registration_request)
    appointment, status_message, patient_id, result_token = bp_finalize_booking(booking_req,
                                                                                finalize_registration_request)

    if finalize_registration_request.ggd_waitlist:
        bp_add_to_ggd_waiting_queue(patient_id)
    if appointment:
        return {
            "session_token": result_token,
            "appointment_id": appointment.id,
            "date": appointment.date_text,
            "location": appointment.location_text,
            'total_balance': int((appointment.billed_amount if appointment.billed_amount else 0) * 100),
            'total_cost': int((appointment.total_cost if appointment.total_cost else 0) * 100),
            'payment_url': appointment.payment_url,
            'payment_checkout_session': appointment.payment_checkout_session,
            c.STATUS: c.SUCCESS
        }
    else:
        return {
            c.STATUS: c.FAILED,
            c.ERROR: status_message
        }


def ggv_finalize_registration(finalize_registration_request):
    booking_req = __map_to_booking_req(finalize_registration_request, ggv=True)

    slot = is_un_available_slot(booking_req.verification_token)
    if slot is None:
        pass
    else:
        return {"status": "This slot is not available"}

    appointment_1, appointment_2, status_message, patient_id, result_token = bp_ggv_finalize_booking(booking_req,
                                                                                                     finalize_registration_request)

    if finalize_registration_request.ggd_waitlist:
        bp_add_to_ggd_waiting_queue(patient_id)
    res = {c.STATUS: c.SUCCESS}
    if appointment_1:
        lock_slot(booking_req.verification_token, patient_id)
        res["session_token"] = result_token
        res["appointment_id_1"] = appointment_1.id
        res["date_1"] = appointment_1.date_text
        res["location_1"] = appointment_1.location_text
        res['total_balance_1'] = int(appointment_1.billed_amount * 100)
        res['total_cost_1'] = int(appointment_1.total_cost * 100)
        res['payment_url_1'] = appointment_1.payment_url

        if appointment_2:
            res["appointment_id_2"] = appointment_2.id
            res["date_2"] = appointment_2.date_text
            res["location_2"] = appointment_2.location_text
            res['total_balance_2'] = int(appointment_2.billed_amount * 100)
            res['total_cost_2'] = int(appointment_2.total_cost * 100)
            res['payment_url_2'] = appointment_2.payment_url

        return res

    else:
        return {
            c.STATUS: c.FAILED,
            c.ERROR: status_message
        }


def ggv_finalize_pre_registration(finalize_registration_request):
    booking_req = __map_to_booking_req(finalize_registration_request, ggv=True)
    status_message, patient_id, patient_questionnaire_id = bp_ggv_finalize_pre_booking(booking_req)

    if patient_id:
        if finalize_registration_request.ggd_waitlist:
            bp_add_to_ggd_waiting_queue(patient_id)
        bp_create_pre_registration(patient_id, patient_questionnaire_id, booking_req.group_code)
        return {
            c.STATUS: c.SUCCESS,
            "pre_register": True,
            "patient_id": patient_id
        }
    else:
        return {
            c.STATUS: c.FAILED,
            c.ERROR: status_message
        }


def __map_to_booking_req(finalize_registration_request, ggv=False):
    b = GgtBooking()
    try:
        if "insuranceVerification" in dict(finalize_registration_request).keys():
            if finalize_registration_request.insuranceVerification:
                b.insurance_relationship = finalize_registration_request.insuranceVerification.relationship
                b.insurance_member_id = finalize_registration_request.insuranceVerification.member_id
                b.insurance_group_no = finalize_registration_request.insuranceVerification.group_no
                b.insurance_payer = finalize_registration_request.insuranceVerification.payer
                b.insurance_level = finalize_registration_request.insuranceVerification.level

        if "covid19vaxScreening" in dict(finalize_registration_request).keys():
            b.ggv_allergies = finalize_registration_request.covid19vaxScreening.allergies
            b.serious_reaction = finalize_registration_request.covid19vaxScreening.serious_reaction
            b.long_term_health = finalize_registration_request.covid19vaxScreening.long_term_health
            b.immune_system = finalize_registration_request.covid19vaxScreening.immune_system
            b.immune_system_medications = finalize_registration_request.covid19vaxScreening.immune_system_medications
            b.nervous_system = finalize_registration_request.covid19vaxScreening.nervous_system
            b.blood_transfusion = finalize_registration_request.covid19vaxScreening.blood_transfusion
            b.recent_vaccinations = finalize_registration_request.covid19vaxScreening.recent_vaccinations

        b.token = finalize_registration_request.token
        b.phone_number = finalize_registration_request.phone_number.strip()
        b.first_name = finalize_registration_request.patientDetails.first_name.strip()
        b.middle_name = finalize_registration_request.patientDetails.middle_name.strip()
        b.last_name = finalize_registration_request.patientDetails.last_name.strip()
        b.gender = finalize_registration_request.gender

        b.address = finalize_registration_request.patientAddress.street.strip()
        b.city = finalize_registration_request.patientAddress.city.strip()
        b.zip = finalize_registration_request.patientAddress.zip_code.strip()
        b.email = finalize_registration_request.patientContact.email.strip()
        b.country = finalize_registration_request.patientAddress.country.strip()

        b.st = finalize_registration_request.patientAddress.state
        b.dob = finalize_registration_request.patientDetails.dob
        if "patientVitals" in dict(finalize_registration_request).keys() and finalize_registration_request.patientVitals:
            b.height = finalize_registration_request.patientVitals.height
            b.weight = finalize_registration_request.patientVitals.weight
            b.meds = finalize_registration_request.patientVitals.medications
        b.ethnicity = finalize_registration_request.ethnicity
        b.race = finalize_registration_request.race

        b.is_patient = finalize_registration_request.isPatient
        b.group_code = finalize_registration_request.groupCode.strip()
        if finalize_registration_request.symptoms:
            b.symptom_fever = finalize_registration_request.symptoms.symptom_fever

            b.symptom_shortbreath = finalize_registration_request.symptoms.symptom_short_breath
            b.symptom_coughing = finalize_registration_request.symptoms.symptom_cough
            b.symptom_chestpains = finalize_registration_request.symptoms.symptom_chest_pains
            b.symptom_others = finalize_registration_request.symptoms.symptom_other
            b.symptom_lack_of_smell = finalize_registration_request.symptoms.symptom_lack_of_smell

            b.symptom_fatigue = finalize_registration_request.symptoms.symptom_fatigue
            b.symptom_muscle_body_aches = finalize_registration_request.symptoms.symptom_muscle_body_aches
            b.symptom_headache = finalize_registration_request.symptoms.symptom_headache
            b.symptom_sore_throat = finalize_registration_request.symptoms.symptom_sore_throat
            b.symptom_congestion_runny_nose = finalize_registration_request.symptoms.symptom_congestion_runny_nose
            b.symptom_nausea_vomitting = finalize_registration_request.symptoms.symptom_nausea_vomitting
            b.symptom_diarrhea = finalize_registration_request.symptoms.symptom_diarrhea

        b.covid_contact = finalize_registration_request.contactTracing

        if "preExistingConditions" in dict(finalize_registration_request).keys() and finalize_registration_request.preExistingConditions:
            b.heart_disease = finalize_registration_request.preExistingConditions.heart_disease
            b.diabetes = finalize_registration_request.preExistingConditions.diabetes
            b.respiratory_disease = finalize_registration_request.preExistingConditions.respiratory_disease
            b.autoimmune_disease = finalize_registration_request.preExistingConditions.autoimmune_disease
            b.other_chronic_disease = finalize_registration_request.preExistingConditions.other_chronic_disease
            b.allergies = finalize_registration_request.preExistingConditions.allergies

        # if the request comes from GGV, then set the vaccination service

        """
        This section of the code will be deprecated as we get all selected services from selectedServices
        """
        if ggv:
            b.service_covid19_vaccine = True
        else:
            if finalize_registration_request.serviceSelection:
                b.service_covid19_test = finalize_registration_request.serviceSelection.COVID_19_TEST
                b.service_flu_shot = finalize_registration_request.serviceSelection.FLU_SHOT
                b.service_consult = finalize_registration_request.serviceSelection.CONSULT
            else:
                # handle errors in form submission where there is no test type submitted
                b.service_covid19_test = True

        b.insurance_photo = finalize_registration_request.insurancePhoto
        if b.insurance_photo and len(b.insurance_photo) > 250:
            b.has_insurance_photo = True
        else:
            b.has_insurance_photo = False

        b.date = finalize_registration_request.date
        b.location_id = finalize_registration_request.location
        b.timeslot_id = finalize_registration_request.timeSlot

        if "appointmentOneTime" in finalize_registration_request.dict().keys():
            b.appointmentOneTime = finalize_registration_request.appointmentOneTime
        if "verification_token" in finalize_registration_request.dict().keys():
            b.verification_token = finalize_registration_request.verification_token
        if "appointmentTwoTime" in finalize_registration_request.dict().keys():
            b.appointmentTwoTime = finalize_registration_request.appointmentTwoTime
        if "symptomsVax" in finalize_registration_request.dict().keys():
            b.symptomsVax = finalize_registration_request.symptomsVax
        if "covid19ConfirmedCase" in finalize_registration_request.dict().keys():
            b.covid19ConfirmedCase = finalize_registration_request.covid19ConfirmedCase
        if "pregnancy" in finalize_registration_request.dict().keys():
            b.pregnancy = finalize_registration_request.pregnancy
        if "allergicReaction" in finalize_registration_request.dict().keys():
            b.allergicReaction = finalize_registration_request.allergicReaction
        if "eggAllergy" in finalize_registration_request.dict().keys():
            b.eggAllergy = finalize_registration_request.eggAllergy
        if "guillianBarre" in finalize_registration_request.dict().keys():
            b.guillianBarre = finalize_registration_request.guillianBarre
        if "pre_register" in finalize_registration_request.dict().keys():
            b.pre_register = finalize_registration_request.pre_register

        if "selectedServices" in dict(finalize_registration_request).keys():
            location_services = []
            selected_services = ServiceCodes()
            # Iterate through each location service item and get the LocationService object
            for item in finalize_registration_request.selectedServices:
                location_service = LocationService()
                location_service.service_code = item
                location_services.append(location_service)
                selected_services = __assign_services(selected_services, item)
            b.location_services = location_services
            b.services = selected_services

        b.language = finalize_registration_request.language
        if "currency" in finalize_registration_request.dict().keys():
            b.currency = finalize_registration_request.currency

        with suppress(AttributeError):
            b.public_places_bars_restaurants_cafes = finalize_registration_request.publicPlaces.bars_restaurants_cafes
            b.public_places_gas_stations = finalize_registration_request.publicPlaces.gas_stations
            b.public_places_medical_offices = finalize_registration_request.publicPlaces.medical_offices
            b.public_places_place_of_work = finalize_registration_request.publicPlaces.place_of_work
            b.public_places_retail_grocery_stores = finalize_registration_request.publicPlaces.retail_grocery_stores
            b.public_places_places_of_worship = finalize_registration_request.publicPlaces.places_of_worship
            b.public_places_public_parks = finalize_registration_request.publicPlaces.public_parks
            b.public_places_other = finalize_registration_request.publicPlaces.other

            b.signature = finalize_registration_request.consent.full_name.strip()
            b.consent_provider_signature = finalize_registration_request.consent_provider.full_name.strip()
            b.provider_consent_custom_field_1 = finalize_registration_request.consent_provider.provider_consent_custom_field_1.strip()
            b.provider_consent_custom_field_2 = finalize_registration_request.consent_provider.provider_consent_custom_field_2.strip()
            b.provider_consent_custom_field_3 = finalize_registration_request.consent_provider.provider_consent_custom_field_3.strip()

            b.influenza_consent_signature = finalize_registration_request.influenzaConsent.full_name.strip()

            b.flu_screen_severely_ill = finalize_registration_request.influenzaScreening.severely_ill
            b.flu_screen_guillain_barre_syndrome = finalize_registration_request.influenzaScreening.guillain_barre_syndrome
            b.flu_screen_life_threatening_reaction = finalize_registration_request.influenzaScreening.life_threatening_reaction
            b.flu_screen_egg_allergy = finalize_registration_request.influenzaScreening.egg_allergy

    except Exception as err:
        log_generic(
            type=c.ERROR,
            function=whoami(),
            finalize_registration_request=finalize_registration_request,
            error=err
        )

    return b


def __assign_services(selected_services, sku):
    if sku == c.SERVICE_CODE_COVID19_TEST_NV:
        selected_services.covid_19_test_nv = True
    if sku == c.SERVICE_CODE_COVID19_TEST:
        selected_services.covid_19_test = True
    if sku == c.SERVICE_CODE_COVID19_TEST_MEXICO:
        selected_services.covid_19_test_mexico = True
    if sku == c.SERVICE_CODE_COVID_19_TEST_MX_RESORT:
        selected_services.covid_19_test_mexico_resort = True
    if sku == c.SERVICE_CODE_COVID19_TEST_ANTIGEN:
        selected_services.covid_19_test_antigen = True
    if sku == c.SERVICE_CODE_COVID19_TEST_ANTIGEN_NV:
        selected_services.covid_19_test_antigen_nv = True
    if sku == c.SERVICE_CODE_COVID19_TEST_MEXICO_ANTIGEN:
        selected_services.covid_19_test_antigen_mexico = True
    if sku == c.SERVICE_CODE_FLU_SHOT:
        selected_services.flue_shot = True
    if sku == c.SERVICE_CODE_CONSULT:
        selected_services.consult = True
    if sku == c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_1:
        selected_services.covid_19_vax_pfizer_1 = True
    if sku == c.SERVICE_CODE_COVID_19_VACCINE_PFIZER_2:
        selected_services.covid_19_vax_pfizer_2 = True
    if sku == c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_1:
        selected_services.covid_19_vax_moderna_1 = True
    if sku == c.SERVICE_CODE_COVID_19_VACCINE_MODERNA_2:
        selected_services.covid_19_vax_moderna_2 = True
    if sku == c.SERVICE_CODE_COVID_19_VACCINE_JNJ:
        selected_services.covid_19_vax_jnj = True
    return selected_services


def insurance_eligibility(insurance_eligibility_request):
    return bp_get_wellpay_insurance_eligibility(insurance_eligibility_request)


def insurance_search_payer(insurance_search_payer_request):
    return bp_search_insurance_payer_list(insurance_search_payer_request)


def verify_verification_token(toke_verification_request):
    return x_response(
        bp_verify_verification_token(toke_verification_request.verification_token)
    )


def get_vax_certificate(patient_id, cert_id, pass_through=False):
    return bp_get_vax_certificate(patient_id, cert_id, pass_through=pass_through)


@cached(cache=TTLCache(maxsize=1024, ttl=180))
def cache_test(t_id):
    x = datetime.now()
    while (datetime.now() - x).seconds < 5:
        pass
    return {"response": t_id}


def get_wallet_pass(pkpass_request):
    return y_response(
         bp_get_wallet_pass(pkpass_request)
    )
def vax_wallet_pass_apple_upadte(device_id, pass_type, serial_no, pushToken, Authorization):
    return x_response(
         bp_vax_wallet_pass_apple_upadte(device_id, pass_type, serial_no, pushToken, Authorization)
    )

def vax_wallet_pass_apple_upadte_serial(device_id, pass_type):
    return x_response(
         bp_vax_wallet_pass_apple_upadte_serial(device_id, pass_type)
    )
def vax_wallet_get_new_pass(serial_no, Authorization):
    return bp_vax_wallet_get_new_pass(serial_no, Authorization)
def call_non_sms_phone(phone_number):
    return x_response(
         bp_call_non_sms_phone(phone_number))


def get_add_vax_certificate(req, booster=False):
    return x_response(
         bp_add_vax_certificate(req, booster)
    )

def add_vax_certificates(req):
    return x_response(
         bp_add_vax_certificates(req)
    )
def update_group_code(req):
    return x_response(
         bp_update_group_code(req)
    )
def pass_verification(req):
    return x_response(
         bp_pass_verification(req)
    )
def update_android_pass(req):
    return x_response(
         bp_update_android_pass(req)
    )


def vax_check_payment(phone_number):
    return x_response(
        bp_vax_check_payment(phone_number)
    )


def vax_yes_payment(req):
    return x_response(
        bp_vax_yes_payment(req)
    )


def vax_yes_verify_payment(session_id):
    return x_response(
        bp_vax_yes_verify_payment(session_id)
    )
