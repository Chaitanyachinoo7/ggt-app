from cachetools import cached, LRUCache, TTLCache

from ggt.lib.adapters.auth0_adapter import get_organization_id
from ggt.lib.utils import (
    x_response
)
from ggt.models.process_models.bp_appointments import (
    bp_get_appointment_info,
    bp_appointment_update
)
from ggt.models.process_models.bp_portal_experience import (
    bp_record_label_scan,
    bp_create_test_sample_from_appointment
)

from ggt.models.process_models.bp_printers import (
    bp_provider_get_workstations
)


'''
bp_get_monthly_calendar,
bp_get_monthly_calendar,
bp_provider_positive_result_followup,
bp_get_user_role,
bp_get_test_results
'''
# TODO: move this to a table for dynamic lookup
ADMIN_TOKEN = "entourage2020"


########################################################################################################
# [Public] functions
########################################################################################################
# TODO: return a token with claims
def provider_login(auth_token):
    return x_response(
        {
            'auth_token': ADMIN_TOKEN
        },
        is_authenticated(auth_token)
    )


'''
def printer_queue_check(printer_id, printer_token):
    return x_response(bp_printer_queue_check)
'''


@cached(cache=TTLCache(maxsize=1024, ttl=600))
def provider_get_workstations():
    return x_response(
        bp_provider_get_workstations()
    )


def provider_lookup_appointment(appointment_id, user):
    org_id = get_organization_id(user)
    return x_response(
        bp_get_appointment_info(appointment_id, 'allowdoboverride', org_id=org_id)
    )


def provider_update_appointment(provider_update_appointment_request, user):
    return x_response(
        bp_appointment_update(provider_update_appointment_request, user)
    )


def scan_label(appointment_id):
    # TODO add to sys log, multiple scans can happen, keeps only latest scan
    bp_create_test_sample_from_appointment(appointment_id)
    return x_response(
        bp_record_label_scan(appointment_id)
    )

########################################################################################################
# [Protected] functions
########################################################################################################

def is_authenticated(auth_token):
    return auth_token == ADMIN_TOKEN
