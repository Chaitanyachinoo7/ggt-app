from cachetools import cached, LRUCache, TTLCache

from ggt.lib.adapters.auth0_adapter import get_organization_id
from ggt.lib.utils import (
    x_response,
    y_response
)
from ggt.models.data_models.appointments import get_service_type_by_appointment_id
from ggt.models.data_models.data_types import SgrCategoryEnum
from ggt.models.data_models.providers import get_provider_processing_list_db

from ggt.models.process_models.bp_care_provider_experience import (
    bp_get_provider_processing_list, bp_lock_provider_task, bp_create_patient_test_consultation,
    bp_update_consultation_note, bp_provider_complete_task, bp_provider_rollback_to_pending_task, bp_call_patient,
    _bp_get_provider_processing_list)


########################################################################################################
# [Public] functions
########################################################################################################
def get_provider_processing_list(provide_request):
    return y_response(
        bp_get_provider_processing_list(provide_request.offset, provide_request.consultation_status,
                                        provide_request.consultation_notes, provide_request.positive_call,
                                        provide_request.limit)
    )


def _get_provider_processing_list(provide_request, user):
    org_id = get_organization_id(user)
    return y_response(
        _bp_get_provider_processing_list(provide_request.offset, provide_request.consultation_status,
                                         provide_request.consultation_notes, provide_request.positive_call,
                                         provide_request.limit, provide_request.start_date, provide_request.end_date,
                                         org_id)
    )


def lock_provider_task(lock_request):
    appointment_type = get_service_type_by_appointment_id(lock_request.appointment_id)
    updated = True
    if appointment_type == SgrCategoryEnum.test.value:
        updated = bp_lock_provider_task(lock_request.test_id)
    if updated:
        return y_response(bp_create_patient_test_consultation(lock_request.appointment_id, lock_request.user_id))
    else:
        return x_response(None)


def update_consultation_note(update_note):
    return x_response(bp_update_consultation_note(update_note.consultation_id, update_note.note))


def call_patient(call_req):
    return y_response(bp_call_patient(call_req.patient_mobile, call_req.provider_mobile))


def provider_complete_task(complete_task):
    appointment_type = get_service_type_by_appointment_id(complete_task.test_id)
    updated = True
    if appointment_type == SgrCategoryEnum.test.value:
        updated = bp_provider_complete_task(complete_task.test_id)

    if updated:
        bp_update_consultation_note(complete_task.consultation_id, complete_task.note,
                                    complete_task.consultation_type_code,
                                    complete_task.resolution_code)
        return y_response(get_provider_processing_list_db(0, 'any', 'any', 'any', test_id=complete_task.test_id))
    else:
        return y_response(None)


"""
Following is a admin task, in case of emergency
"""


def provider_rollback_to_pending_task(test_id):
    return x_response(bp_provider_rollback_to_pending_task(test_id))

########################################################################################################
# [Protected] functions
########################################################################################################
